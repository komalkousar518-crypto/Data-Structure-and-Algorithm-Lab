#include<iostream>
using namespace std;

int main(){
    // Allocate memory for one character
    char*ch=new char;
    // Store character
    cout<<"Enter a character:";
    cin>>*ch;
   // Print character
    cout<<"Stored character:"<<*ch<<endl;
   // Deallocate memory
    delete ch;
    ch=nullptr;
    return 0;
}
