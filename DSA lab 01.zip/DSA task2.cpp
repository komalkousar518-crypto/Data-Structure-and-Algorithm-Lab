#include<iostream>
using namespace std;
int main()
{
	int arr[4]={1,2,3,4};
	int n=4;
	cout<<"reverse array=";
	for(int i=n-1;i>=0;i--){
		cout<<arr[i]<<" ";
	}
	return 0;
} 